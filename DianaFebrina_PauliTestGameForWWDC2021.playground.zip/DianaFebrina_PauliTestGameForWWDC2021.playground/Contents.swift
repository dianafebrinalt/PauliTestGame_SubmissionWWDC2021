import UIKit
import PlaygroundSupport

class FirstPage: UIViewController {
    
    var backgroundForPageWelcome = UIImageView()
    var labelWelcomeTo = UILabel()
    var labelPauliTestGame = UILabel()
    let imageOfPauliTest = UIImageView()
    var buttonToSecondPage = UIButton()
    
    override func viewDidLoad() {
        
        //to set and input image for background in welcome page
        backgroundForPageWelcome.image = UIImage(named: "backgroundawal.tiff") //--> Cara untuk menampilkan gambar
        backgroundForPageWelcome.frame = CGRect(x: 90, y: 150, width: 600, height: 600) //--> Cara mengatur ukurannya
        
        //to create and set text 'WELCOME TO'
        labelWelcomeTo.text = "WELCOME TO"
        labelWelcomeTo.frame = CGRect(x: 265, y: 100, width: 300, height: 300)
        labelWelcomeTo.textColor = .darkGray
        labelWelcomeTo.font = UIFont(name: "Arial Rounded MT Bold", size: 40)
        labelWelcomeTo.textAlignment = .justified
        
        //to create and set text 'PAULI TEST GAME 🧮'
        labelPauliTestGame.text = "PAULI TEST GAME 🧮"
        labelPauliTestGame.frame = CGRect(x: 270, y: 165, width: 300, height: 300)
        labelPauliTestGame.textColor = .darkGray
        labelPauliTestGame.font = UIFont(name: "Arial Rounded MT Bold", size: 25)
        labelPauliTestGame.textAlignment = .justified
        
        //to set and input image about pauli test. so, become an overview how pauli test is
        imageOfPauliTest.image = UIImage(named: "teskoran.tiff")
        imageOfPauliTest.frame = CGRect(x: 320, y: 400, width: 160, height: 175)
        
        //to create button 'Next' for navigate user to go to the next page
        buttonToSecondPage.setTitle("Next", for: .normal)
        buttonToSecondPage.frame = CGRect(x: 580, y: 690, width: 80, height: 30)
        buttonToSecondPage.titleLabel?.font = UIFont.init(name: "Arial Rounded MT Bold", size: 15)
        buttonToSecondPage.setTitleColor(.darkGray, for: .normal)
        buttonToSecondPage.backgroundColor = .systemGray3
        buttonToSecondPage.layer.cornerRadius = 12
        //Agar tombol bisa di klik
        buttonToSecondPage.addTarget(self, action: #selector (clickButtonNext2ndPage) ,for: .touchUpInside)
        
        
        //to show all component that i have create into the live view.
        view.addSubview(backgroundForPageWelcome)
        view.addSubview(labelWelcomeTo)
        view.addSubview(labelPauliTestGame)
        view.addSubview(imageOfPauliTest)
        view.addSubview(buttonToSecondPage)
    }
    
    //this is the func to go to the secondpage class, if we called this func so it will do what i have make into the function, for example : view.removeFromSuperview , so when we go to second page, this page will be remove.
    
    @objc func clickButtonNext2ndPage (sender: UIButton){
        view.removeFromSuperview()
        //print("Yuhuuu, Next Page")
        PlaygroundPage.current.liveView = SecondPage()
    }
}

//To show class FirsPage into the live view
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = FirstPage()

