import Foundation
import UIKit
import PlaygroundSupport

public class ResultPage : UIViewController{
    
    var backgroundForPageResult = UIImageView()
    var labelYourResult = UILabel()
    var labelTrueCheck = UILabel()
    var labelFalse = UILabel()
    var labelImageTimer = UILabel()
    var labelTotalQs = UILabel()
    var labelSign1 = UILabel()
    var labelSign2 = UILabel()
    var labelSign3 = UILabel()
    var labelSign4 = UILabel()
    var labelTotalTrue = UILabel()
    var labelTotalFalse = UILabel()
    var labelTotalTimer = UILabel()
    var labelTotalQuestion = UILabel()
    
    var buttonPlayAgain = UIButton()
    
    var answer : [Bool]?
    var jumlahSoal : Int?
    var timer : Int?
    
    public override func viewDidLoad() {
        
        //create background for Result Page
        backgroundForPageResult.image = UIImage(named: "bgResult.tiff")
        backgroundForPageResult.frame = CGRect(x: 200, y: 150, width: 400, height: 600)
        
        //set the text "Your Result 📜" and this is become the title of this result page
        labelYourResult.text = "Your Result 📜"
        labelYourResult.frame = CGRect(x: 310, y: 170, width: 200, height: 80)
        labelYourResult.textColor = .darkGray
        labelYourResult.font = UIFont(name: "Arial Rounded MT Bold", size: 25)
        labelYourResult.textAlignment = .center
        
        //label true Check
        labelTrueCheck.text = "✅"
        labelTrueCheck.frame = CGRect(x: 280, y: 300, width: 80, height: 80)
        labelTrueCheck.font = UIFont(name: "Arial Rounded MT Bold", size: 40)
        
        //set label sign to
        labelSign1.text = "→"
        labelSign1.frame = CGRect(x: 380, y: 300, width: 80, height: 80)
        labelSign1.font = UIFont(name: "Arial Rounded MT Bold", size: 30)
        
        //label to set the Total True
        labelTotalTrue.text = ""
        labelTotalTrue.frame = CGRect(x: 440, y: 300, width: 80, height: 80)
        labelTotalTrue.font = UIFont(name: "Arial Rounded MT Bold", size: 20)
        
        //falseCheck
        labelFalse.text = "❎"
        labelFalse.frame = CGRect(x: 280, y: 380, width: 80, height: 80)
        labelFalse.font = UIFont(name: "Arial Rounded MT Bold", size: 40)
        
        //set label sign to
        labelSign2.text = "→"
        labelSign2.frame = CGRect(x: 380, y: 380, width: 80, height: 80)
        labelSign2.font = UIFont(name: "Arial Rounded MT Bold", size: 30)
        
        //label to set Total False
        labelTotalFalse.text = ""
        labelTotalFalse.frame = CGRect(x: 440, y: 380, width: 80, height: 80)
        labelTotalFalse.font = UIFont(name: "Arial Rounded MT Bold", size: 20)
        
        //to create text memoji timer
        labelImageTimer.text = "⏱"
        labelImageTimer.frame = CGRect(x: 280, y: 460, width: 80, height: 80)
        labelImageTimer.font = UIFont(name: "Arial Rounded MT Bold", size: 40)
        
        //set label sign to
        labelSign3.text = "→"
        labelSign3.frame = CGRect(x: 380, y: 460, width: 80, height: 80)
        labelSign3.font = UIFont(name: "Arial Rounded MT Bold", size: 30)
        
        //label to set total timer
        labelTotalTimer.text = ""
        labelTotalTimer.frame = CGRect(x: 440, y: 460, width: 150, height: 80)
        labelTotalTimer.font = UIFont(name: "Arial Rounded MT Bold", size: 20)
        
        //Total Questions
        labelTotalQs.text = "Total Qs"
        labelTotalQs.frame = CGRect(x: 280, y: 540, width: 80, height: 80)
        labelTotalQs.font = UIFont(name: "Arial Rounded MT Bold", size: 20)
        labelTotalQs.textAlignment = .justified
        labelTotalQs.textColor = .darkGray
    
        //set label sign to
        labelSign4.text = "→"
        labelSign4.frame = CGRect(x: 380, y: 540, width: 80, height: 80)
        labelSign4.font = UIFont(name: "Arial Rounded MT Bold", size: 30)
        
        //label to set total questions
        labelTotalQuestion.text = ""
        labelTotalQuestion.frame = CGRect(x: 440, y: 540, width: 150, height: 80)
        labelTotalQuestion.font = UIFont(name: "Arial Rounded MT Bold", size: 20)
        
        //to create button play again, when user want to play this game again
        buttonPlayAgain.setTitle("↩︎", for: .normal)
        buttonPlayAgain.frame = CGRect(x: 380, y: 670, width: 50, height: 50)
        buttonPlayAgain.backgroundColor = .black
        buttonPlayAgain.titleLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 30)
        buttonPlayAgain.setTitleColor(.white, for: .normal)
        buttonPlayAgain.layer.cornerRadius = 12
        buttonPlayAgain.addTarget(self, action: #selector(screenPlayPage), for: .touchUpInside)
        
        
        view.addSubview(backgroundForPageResult)
        view.addSubview(labelYourResult)
        view.addSubview(labelTrueCheck)
        view.addSubview(labelFalse)
        view.addSubview(labelImageTimer)
        view.addSubview(labelTotalQs)
        view.addSubview(labelSign1)
        view.addSubview(labelSign2)
        view.addSubview(labelSign3)
        view.addSubview(labelSign4)
        view.addSubview(labelTotalTrue)
        view.addSubview(labelTotalFalse)
        view.addSubview(labelTotalTimer)
        view.addSubview(labelTotalQuestion)
        view.addSubview(buttonPlayAgain)
        
        result()
    }
    
    //to go to page play page when the user want to play this game again
    @objc func screenPlayPage(){
        view.removeFromSuperview()
        PlaygroundPage.current.liveView = SetTheTimerPage()
    }
    
    //this func to calculate the result
    @objc func result() {
        var totalOfTrue : Int = 0
        var totalOfFalse : Int = 0
        for output in self.answer! {
            if output {
                totalOfTrue = totalOfTrue + 1
            }
            else {
                totalOfFalse = totalOfFalse + 1
            }
        }
        // tambah dibawah ini
        labelTotalTrue.text = "\(totalOfTrue)"
        labelTotalFalse.text = "\(totalOfFalse)"
        labelTotalTimer.text = "\(timer!) Second"
        labelTotalQuestion.text = "\(jumlahSoal!) Questions"
    }
}

