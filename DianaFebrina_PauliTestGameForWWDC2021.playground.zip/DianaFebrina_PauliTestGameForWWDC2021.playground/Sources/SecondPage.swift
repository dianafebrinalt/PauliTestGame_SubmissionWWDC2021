import Foundation
import PlaygroundSupport
import UIKit


public class SecondPage : UIViewController{
    
    var backgroundForSecondPage = UIImageView()
    var pauliTestImage = UIImageView()
    var textPauli1 = UILabel()
    var textPauli2 = UILabel()
    var textPauli3 = UILabel()
    var textPauli4 = UILabel()
    var textPauli5 = UILabel()
    var textPauli6 = UILabel()
    var textPauli7 = UILabel()
    var textPauli8 = UILabel()
    var textPauli9 = UILabel()
    var textPauli10 = UILabel()
    var textPauli11 = UILabel()
    var textPauli12 = UILabel()
    var buttonPlayPage = UIButton()
    
    
    public override func viewDidLoad() {
        
        //to set and input image for second page's background
        backgroundForSecondPage.image = UIImage(named: "backgroundawal.tiff")
        backgroundForSecondPage.frame = CGRect(x: 90, y: 150, width: 600, height: 600)
        
        //to set and input image about pauli test. so, become an overview how pauli test is
        pauliTestImage.image = UIImage(named: "teskoran.tiff") //--> Cara untuk menampilkan gambar
        pauliTestImage.frame = CGRect(x: 310, y: 170, width: 150, height: 160) //--> Cara mengatur ukurannya
        
        //to create caption in line 1
        textPauli1.text = "In my country, Indonesia. There is a test called 'Newspaper Test'"
        textPauli1.textColor = .black
        textPauli1.frame = CGRect(x: 130, y: 315, width: 600, height: 80)
        textPauli1.font = UIFont(name: "Arial Rounded MT Bold", size: 17)
        textPauli1.textAlignment = .justified
        
        //to create caption in line 2
        textPauli2.text = "Or in more Familiar International Designations called  'Pauli Test'"
        textPauli2.textColor = .black
        textPauli2.frame = CGRect(x: 130, y: 340, width: 600, height: 80)
        textPauli2.font = UIFont(name: "Arial Rounded MT Bold", size: 17)
        textPauli2.textAlignment = .justified
        
        //to create caption in line 3
        textPauli3.text = "This Pauli or Newspaper Test aims to Measure the Consistency &"
        textPauli3.textColor = .black
        textPauli3.frame = CGRect(x: 130, y: 365, width: 600, height: 80)
        textPauli3.font = UIFont(name: "Arial Rounded MT Bold", size: 17)
        textPauli3.textAlignment = .justified
        
        //to create caption in line 4
        textPauli4.text = "Speed, Accuracy & Resistance when someone calculates simple"
        textPauli4.textColor = .black
        textPauli4.frame = CGRect(x: 130, y: 390, width: 600, height: 80)
        textPauli4.font = UIFont(name: "Arial Rounded MT Bold", size: 17)
        textPauli4.textAlignment = .justified
        
        //to create caption in line 5
        textPauli5.text = "addition math problem and will interpret the person's personality "
        textPauli5.textColor = .black
        textPauli5.frame = CGRect(x: 130, y: 415, width: 600, height: 80)
        textPauli5.font = UIFont(name: "Arial Rounded MT Bold", size: 17)
        textPauli5.textAlignment = .justified
        
        //to create caption in line 6
        textPauli6.text = "measures. And Usually this Test is used when trying Army or etc."
        textPauli6.textColor = .black
        textPauli6.frame = CGRect(x: 130, y: 440, width: 600, height: 80)
        textPauli6.font = UIFont(name: "Arial Rounded MT Bold", size: 17)
        textPauli6.textAlignment = .justified
        
        //to create caption in line 7
        textPauli7.text = "So, I Inspired to make this test into a game, to help my lil brother"
        textPauli7.textColor = .black
        textPauli7.frame = CGRect(x: 130, y: 480, width: 600, height: 80)
        textPauli7.font = UIFont(name: "Arial Rounded MT Bold", size: 17)
        textPauli7.textAlignment = .justified
        
        //to create caption in line 8
        textPauli8.text = "who want to try Army . How to play this game is first set the time"
        textPauli8.textColor = .black
        textPauli8.frame = CGRect(x: 130, y: 505, width: 600, height: 80)
        textPauli8.font = UIFont(name: "Arial Rounded MT Bold", size: 17)
        textPauli8.textAlignment = .justified
        
        //to create caption in line 9
        textPauli9.text = "by moving the time slider, then click start. And add the 2 random"
        textPauli9.textColor = .black
        textPauli9.frame = CGRect(x: 130, y: 530, width: 600, height: 80)
        textPauli9.font = UIFont(name: "Arial Rounded MT Bold", size: 17)
        textPauli9.textAlignment = .justified

        //to create caption in line 10
        textPauli10.text = "number available, then click on the button 0 to 9 according to the"
        textPauli10.textColor = .black
        textPauli10.frame = CGRect(x: 130, y: 555, width: 600, height: 80)
        textPauli10.font = UIFont(name: "Arial Rounded MT Bold", size: 17)
        textPauli10.textAlignment = .justified
        
        //to create caption in line 11
        textPauli11.text = "sum of the 2 random numbers. If the sum is have two digits, then"
        textPauli11.textColor = .black
        textPauli11.frame = CGRect(x: 130, y: 580, width: 600, height: 80)
        textPauli11.font = UIFont(name: "Arial Rounded MT Bold", size: 17)
        textPauli11.textAlignment = .justified
        
        //to create caption in line 12
        textPauli12.text = "the number that become the answer is the last number of the sum."
        textPauli12.textColor = .black
        textPauli12.frame = CGRect(x: 130, y: 605, width: 600, height: 80)
        textPauli12.font = UIFont(name: "Arial Rounded MT Bold", size: 17)
        textPauli12.textAlignment = .justified
        
        
        //this button to go to next page, which is in that page, we will play the game, but the first time before we play, we must set the timer so we can start it.
        buttonPlayPage.setTitle("Play Now!", for: .normal)
        buttonPlayPage.frame = CGRect(x: 318, y: 690, width: 150, height: 30)
        buttonPlayPage.setTitleColor(.darkGray, for: .normal)
        buttonPlayPage.titleLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 15)
        buttonPlayPage.backgroundColor = .systemGray3
        buttonPlayPage.layer.cornerRadius = 12
        buttonPlayPage.addTarget(self, action: #selector (clickButtonPlay), for: .touchUpInside)
        
        
        
        view.addSubview(backgroundForSecondPage)
        view.addSubview(pauliTestImage)
        view.addSubview(textPauli1)
        view.addSubview(textPauli2)
        view.addSubview(textPauli3)
        view.addSubview(textPauli4)
        view.addSubview(textPauli5)
        view.addSubview(textPauli6)
        view.addSubview(textPauli7)
        view.addSubview(textPauli8)
        view.addSubview(textPauli9)
        view.addSubview(textPauli10)
        view.addSubview(textPauli11)
        view.addSubview(textPauli12)
        view.addSubview(buttonPlayPage)
        }
    
    //this is the func to go to the Play Page class, if we called this func so it will do what i have make into the function
    @objc func clickButtonPlay(sender: UIButton) {
        view.removeFromSuperview()
        //print("Yuhuuu Play")
        PlaygroundPage.current.liveView = SetTheTimerPage()
    }
}
