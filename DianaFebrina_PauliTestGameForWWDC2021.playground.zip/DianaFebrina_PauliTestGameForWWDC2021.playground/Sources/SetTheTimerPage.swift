import Foundation
import UIKit
import PlaygroundSupport

public class SetTheTimerPage : UIViewController {
    
    var backgroundForPlayPage = UIImageView()
    var labelSetYourTimer = UILabel()
    var labelPictTimer = UILabel()
    var sliderTimer = UISlider()
    var labelSliderTimer = UILabel()
    var labelTimer = UILabel()
    var label5second = UILabel()
    var label60second = UILabel()
    var buttonStartGame = UIButton()
    
    var second = 30
    var timer = Timer()
    
    
    public override func viewDidLoad() {
        
        //to set and input background for play page
        backgroundForPlayPage.image = UIImage(named: "backgroundSetTimer.tiff")
        backgroundForPlayPage.frame = CGRect(x: 150, y: 300, width: 500, height: 300)
        
        //to create the text "Set your timer to play this Game!"
        labelSetYourTimer.text = "Set your timer to play this Game!"
        labelSetYourTimer.font = UIFont(name: "Arial Rounded MT Bold", size: 20)
        labelSetYourTimer.frame = CGRect(x: 250, y: 310, width: 500, height: 80)
        labelSetYourTimer.textColor = .white
        labelSetYourTimer.textAlignment = .justified
        
        //to set the picture timer but this is not image, but memoji so it is become text.
        labelPictTimer.text = "⏱"
        labelPictTimer.font = UIFont(name: "Arial Rounded MT Bold", size: 70)
        labelPictTimer.frame = CGRect(x: 165, y: 320, width: 80, height: 80)

        //to create label 5 , this is I make to tell user that minimum range of the timer is 5 second
        label5second.text = "5"
        label5second.font = UIFont(name: "Arial Rounded MT Bold", size: 20)
        label5second.frame = CGRect(x: 240, y: 425, width: 250, height: 100)
        label5second.textColor = .black
        label5second.textAlignment = .justified
        
        //to create label 5 , this is I make to tell user that maximum range of the timer is 60 second
        label60second.text = "60"
        label60second.font = UIFont(name: "Arial Rounded MT Bold", size: 20)
        label60second.frame = CGRect(x: 550, y: 425, width: 250, height: 100)
        label60second.textColor = .black
        label60second.textAlignment = .justified

        //slider timer I make for set the timer before start the game
        sliderTimer.frame = CGRect(x: 280, y: 425, width: 250, height: 100)
        sliderTimer.minimumTrackTintColor = .gray
        sliderTimer.maximumTrackTintColor = .white
        sliderTimer.thumbTintColor = .darkGray
        
        //to set value max and min in the slider timer
        sliderTimer.maximumValue = 60
        sliderTimer.minimumValue = 5
        sliderTimer.value = Float(second)
        sliderTimer.addTarget(self, action: #selector(setSliderTimer), for: .valueChanged)
        labelSliderTimer.text = "\(Int(sliderTimer.value)) Second"
        
        //to help user know what the time when the slide the slider timer, so the user will be easy to set the timer based on the user want
        labelSliderTimer.text = ""
        labelSliderTimer.frame = CGRect(x: 350, y: 420, width: 250, height: 40)
        labelSliderTimer.textAlignment = .justified
        labelSliderTimer.font = UIFont(name: "Arial Rounded MT Bold", size: 20)
        labelSliderTimer.textColor = .darkGray

        //to create button start game
        buttonStartGame.setTitle("Start", for: .normal)
        buttonStartGame.setTitleColor(.white, for: .normal)
        buttonStartGame.titleLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 15)
        buttonStartGame.backgroundColor = .black
        buttonStartGame.frame = CGRect(x: 345, y: 550, width: 100, height: 30)
        buttonStartGame.layer.cornerRadius = 12
        buttonStartGame.addTarget(self, action: #selector(clickButtonStart), for: .touchUpInside)
        
        
        view.addSubview(backgroundForPlayPage)
        view.addSubview(labelSetYourTimer)
        view.addSubview(labelPictTimer)
        view.addSubview(label5second)
        view.addSubview(label60second)
        view.addSubview(sliderTimer)
        view.addSubview(labelSliderTimer)
        view.addSubview(buttonStartGame)
    }
    
    @objc func setSliderTimer(sender: UISlider){
        second = Int(sender.value)
        labelSliderTimer.text = "\(Int(sender.value)) Second"
        //timeFinish = Int(sender.value)
    }
    
    @objc func clickButtonStart(sender: UIButton){
        view.removeFromSuperview()
        let scene = StartGame()
        scene.time = Int(second)
        PlaygroundPage.current.liveView = scene
    }
}

