import Foundation
import PlaygroundSupport
import UIKit

public class StartGame : UIViewController{
    
    var backgroundForStartGamePage = UIImageView()
    var bgFor1stRandomNumber = UIImageView()
    var label1stRandomNumber = UILabel()
    var bgFor2ndRandomNumber = UIImageView()
    var label2ndRandomNumber = UILabel()
    var labelImageTimer = UIImageView()
    var labelSignAsk = UILabel()
    var buttonAnswer0 = UIButton()
    var buttonAnswer1 = UIButton()
    var buttonAnswer2 = UIButton()
    var buttonAnswer3 = UIButton()
    var buttonAnswer4 = UIButton()
    var buttonAnswer5 = UIButton()
    var buttonAnswer6 = UIButton()
    var buttonAnswer7 = UIButton()
    var buttonAnswer8 = UIButton()
    var buttonAnswer9 = UIButton()
    var timerOfTheTest = UILabel()
    
    var answer : [Bool] = []
    var timer = Timer()
    var totalOfTheQuestion : Int = 0
    var timeFinish  : Int = 0
    var time : Int?

    public override func viewDidLoad() {
        
        //this to declarate that value of var timeFinish get from value in the var time
        timeFinish = time!
        
        
        
        //set background play game page
        backgroundForStartGamePage.image = UIImage(named: "backgroundPlay.tiff")
        backgroundForStartGamePage.frame = CGRect(x: 90, y: 150, width: 600, height: 600)
    
        //set bg 1st random number
        bgFor1stRandomNumber.image = UIImage(named: "pictSetNumber.tiff")
        bgFor1stRandomNumber.frame = CGRect(x: 350, y: 200, width: 80, height: 80)
        
        //set bg 2nd random number
        bgFor2ndRandomNumber.image = UIImage(named: "pictSetNumber.tiff")
        bgFor2ndRandomNumber.frame = CGRect(x: 350, y: 315, width: 80, height: 80)
        
        //make background for timer
        labelImageTimer.image = UIImage(named: "timer.tiff")
        labelImageTimer.frame = CGRect(x: 150, y: 200, width: 120, height: 120)
        
        //set timer Of The Test
        timerOfTheTest.text = ""
        timerOfTheTest.frame = CGRect(x: 150, y: 210, width: 120, height: 120)
        timerOfTheTest.font = UIFont(name: "Arial Rounded MT Bold", size: 18)
        timerOfTheTest.textColor = .black
        timerOfTheTest.textAlignment = .center
        
        //set label ?
        labelSignAsk.text = "?"
        labelSignAsk.frame = CGRect(x: 450, y: 260, width: 80, height: 80)
        labelSignAsk.font = UIFont(name: "Arial Rounded MT Bold", size: 80)
        labelSignAsk.textColor = .systemGray3
        
        //set the label 1st random number, and the label will be fill by random
        label1stRandomNumber.text = ""
        label1stRandomNumber.frame = CGRect(x: 350, y: 200, width: 80, height: 80)
        label1stRandomNumber.textAlignment = .center
        label1stRandomNumber.font = UIFont(name: "Arial Rounded MT Bold", size: 40)
        label1stRandomNumber.textColor = .darkGray
        
        //set the label 2nd random number, and the label will be fill by random
        label2ndRandomNumber.text = ""
        label2ndRandomNumber.frame = CGRect(x: 350, y: 315, width: 80, height: 80)
        label2ndRandomNumber.textAlignment = .center
        label2ndRandomNumber.font = UIFont(name: "Arial Rounded MT Bold", size: 40)
        label2ndRandomNumber.textColor = .darkGray
        
        
        //This all to set the button answer
        
        //button answer 1
        buttonAnswer1.setTitle("1", for: .normal)
        buttonAnswer1.setTitleColor(.white, for: .normal)
        buttonAnswer1.backgroundColor = .systemGray
        buttonAnswer1.frame = CGRect(x: 180, y: 450, width: 100, height: 50)
        buttonAnswer1.titleLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 20)
        buttonAnswer1.layer.cornerRadius = 12
        buttonAnswer1.addTarget(self, action: #selector(buttonOne), for: .touchUpInside)
        
        //button answer 2
        buttonAnswer2.setTitle("2", for: .normal)
        buttonAnswer2.setTitleColor(.white, for: .normal)
        buttonAnswer2.backgroundColor = .systemGray
        buttonAnswer2.frame = CGRect(x: 345, y: 450, width: 100, height: 50)
        buttonAnswer2.titleLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 20)
        buttonAnswer2.layer.cornerRadius = 12
        buttonAnswer2.addTarget(self, action: #selector(buttonTwo), for: .touchUpInside)
        
        //button answer 3
        buttonAnswer3.setTitle("3", for: .normal)
        buttonAnswer3.setTitleColor(.white, for: .normal)
        buttonAnswer3.backgroundColor = .systemGray
        buttonAnswer3.frame = CGRect(x: 510, y: 450, width: 100, height: 50)
        buttonAnswer3.titleLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 20)
        buttonAnswer3.layer.cornerRadius = 12
        buttonAnswer3.addTarget(self, action: #selector(buttonThree), for: .touchUpInside)
        
        //button answer 4
        buttonAnswer4.setTitle("4", for: .normal)
        buttonAnswer4.setTitleColor(.white, for: .normal)
        buttonAnswer4.backgroundColor = .systemGray
        buttonAnswer4.frame = CGRect(x: 180, y: 520, width: 100, height: 50)
        buttonAnswer4.titleLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 20)
        buttonAnswer4.layer.cornerRadius = 12
        buttonAnswer4.addTarget(self, action: #selector(buttonFour), for: .touchUpInside)
        
        //button answer 5
        buttonAnswer5.setTitle("5", for: .normal)
        buttonAnswer5.setTitleColor(.white, for: .normal)
        buttonAnswer5.backgroundColor = .systemGray
        buttonAnswer5.frame = CGRect(x: 345, y: 520, width: 100, height: 50)
        buttonAnswer5.titleLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 20)
        buttonAnswer5.layer.cornerRadius = 12
        buttonAnswer5.addTarget(self, action: #selector(buttonFive), for: .touchUpInside)
        
        //button answer 6
        buttonAnswer6.setTitle("6", for: .normal)
        buttonAnswer6.setTitleColor(.white, for: .normal)
        buttonAnswer6.backgroundColor = .systemGray
        buttonAnswer6.frame = CGRect(x: 510, y: 520, width: 100, height: 50)
        buttonAnswer6.titleLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 20)
        buttonAnswer6.layer.cornerRadius = 12
        buttonAnswer6.addTarget(self, action: #selector(buttonSix), for: .touchUpInside)
        
        //button answer 7
        buttonAnswer7.setTitle("7", for: .normal)
        buttonAnswer7.setTitleColor(.white, for: .normal)
        buttonAnswer7.backgroundColor = .systemGray
        buttonAnswer7.frame = CGRect(x: 180, y: 585, width: 100, height: 50)
        buttonAnswer7.titleLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 20)
        buttonAnswer7.layer.cornerRadius = 12
        buttonAnswer7.addTarget(self, action: #selector(buttonSeven), for: .touchUpInside)
        
        //button answer 8
        buttonAnswer8.setTitle("8", for: .normal)
        buttonAnswer8.setTitleColor(.white, for: .normal)
        buttonAnswer8.backgroundColor = .systemGray
        buttonAnswer8.frame = CGRect(x: 345, y: 585, width: 100, height: 50)
        buttonAnswer8.titleLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 20)
        buttonAnswer8.layer.cornerRadius = 12
        buttonAnswer8.addTarget(self, action: #selector(buttonEight), for: .touchUpInside)
        
        //button answer 9
        buttonAnswer9.setTitle("9", for: .normal)
        buttonAnswer9.setTitleColor(.white, for: .normal)
        buttonAnswer9.backgroundColor = .systemGray
        buttonAnswer9.frame = CGRect(x: 510, y: 585, width: 100, height: 50)
        buttonAnswer9.titleLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 20)
        buttonAnswer9.layer.cornerRadius = 12
        buttonAnswer9.addTarget(self, action: #selector(buttonNine), for: .touchUpInside)
        
        //button answer 0
        buttonAnswer0.setTitle("0", for: .normal)
        buttonAnswer0.setTitleColor(.white, for: .normal)
        buttonAnswer0.backgroundColor = .systemGray
        buttonAnswer0.frame = CGRect(x: 345, y: 650, width: 100, height: 50)
        buttonAnswer0.titleLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 20)
        buttonAnswer0.layer.cornerRadius = 12
        buttonAnswer0.addTarget(self, action: #selector(buttonZero), for: .touchUpInside)
        
        
        view.addSubview(backgroundForStartGamePage)
        view.addSubview(bgFor1stRandomNumber)
        view.addSubview(bgFor2ndRandomNumber)
        view.addSubview(labelSignAsk)
        view.addSubview(label1stRandomNumber)
        view.addSubview(label2ndRandomNumber)
        view.addSubview(labelImageTimer)
        view.addSubview(timerOfTheTest)
        view.addSubview(buttonAnswer0)
        view.addSubview(buttonAnswer1)
        view.addSubview(buttonAnswer2)
        view.addSubview(buttonAnswer3)
        view.addSubview(buttonAnswer4)
        view.addSubview(buttonAnswer5)
        view.addSubview(buttonAnswer6)
        view.addSubview(buttonAnswer7)
        view.addSubview(buttonAnswer8)
        view.addSubview(buttonAnswer9)
        
        //to countdown the time that have setted before in the set the timer page
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(StartGame.countdownTheTime), userInfo: nil, repeats: true)
        
        //this code to random the number , and the number will be change by random when we have clicked one of button answer from 0 to 9
        label1stRandomNumber.text = "\(Int.random(in: 0...9))"
        label2ndRandomNumber.text = "\(Int.random(in: 0...9))"
    }
    
    @objc func countdownTheTime(){
        time = time! - 1
        timerOfTheTest.text = String(time!) + " Second"
    
        if (time == 0)
        {
            let vc = ResultPage()
            vc.answer = self.answer
            vc.jumlahSoal = totalOfTheQuestion
            vc.timer = self.timeFinish
            PlaygroundPage.current.liveView = vc
            
            timer.invalidate()
        }
    }
    
    @objc func buttonZero(_ sender: Any) {
        setAnswer(answerButton: 0)
    }
    
    @objc func buttonOne(_ sender: Any) {
        setAnswer(answerButton: 1)
    }
    @objc func buttonTwo(_ sender: Any) {
        setAnswer(answerButton: 2)
    }
    @objc func buttonThree(_ sender: Any) {
        setAnswer(answerButton: 3)
    }
    @objc func buttonFour(_ sender: Any) {
        setAnswer(answerButton: 4)
    }
    @objc func buttonFive(_ sender: Any) {
        setAnswer(answerButton: 5)
    }
    @objc func buttonSix(_ sender: Any) {
        setAnswer(answerButton: 6)
    }
    @objc func buttonSeven(_ sender: Any) {
        setAnswer(answerButton: 7)
    }
    @objc func buttonEight(_ sender: Any) {
        setAnswer(answerButton: 8)
    }
    @objc func buttonNine(_ sender: Any) {
        setAnswer(answerButton: 9)
    }
    
    @objc func setAnswer(answerButton : Int){
        var o1Number = Int(label1stRandomNumber.text ?? "0")
        var o2Number = Int(label2ndRandomNumber.text ?? "0")
        var sum = (o1Number! + o2Number!)%10
        
        if sum == answerButton {
            answer.append(true)
        }
        else {
            answer.append(false)
        }
        
         label1stRandomNumber.text = "\(Int.random(in: 0...9))"
         label2ndRandomNumber.text = "\(Int.random(in: 0...9))"
         totalOfTheQuestion = totalOfTheQuestion + 1
    }

}
